# VDP-Finder
This extension tells if visited sites have vulnerability disclosure programs

## Install in your browser
* For Mozilla Firefox: [https://addons.mozilla.org/en-US/firefox/addon/yeswehack-vdp-finder/](https://addons.mozilla.org/en-US/firefox/addon/yeswehack-vdp-finder/)
* For Google Chrome: [https://chrome.google.com/webstore/detail/yeswehack-vdp-finder/jnknjejacdkpnaacfgolbmdohkhpphjb?hl=en](https://chrome.google.com/webstore/detail/yeswehack-vdp-finder/jnknjejacdkpnaacfgolbmdohkhpphjb?hl=en)

